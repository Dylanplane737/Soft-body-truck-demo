import type { NextConfig } from "next";

// GitHub Pages serves from a subpath (https://<user>.github.io/<repo>/),
// so we read the base path from an env var at build time. Default to "" so
// local dev and user/organization pages (which serve from root) still work.
const basePath = process.env.NEXT_PUBLIC_BASE_PATH ?? "";

const nextConfig: NextConfig = {
  // Produce a fully static site in ./out — required for GitHub Pages.
  output: "export",
  // next/image optimization needs a server; disable it for static hosting.
  images: { unoptimized: true },
  // Append trailing slashes so GitHub Pages resolves nested asset paths.
  trailingSlash: true,
  // Optional: comment this out to see real TS errors while developing.
  typescript: { ignoreBuildErrors: true },
  reactStrictMode: false,
  // Makes every asset URL resolve under the repo subpath on Pages.
  basePath,
};

export default nextConfig;
