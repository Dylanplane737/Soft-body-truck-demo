import * as THREE from "three";

/* =====================================================================
 *  CarSim — a self-contained 3D arcade car simulation with softbody-style
 *  crash deformation. Built on Three.js. No external physics library.
 *
 *  Public surface:
 *    const sim = new CarSim(canvas)
 *    sim.input.throttle / brake / steer / handbrake / reset
 *    sim.setColor(idx) / sim.setCameraMode(mode) / sim.setNight(bool)
 *    sim.getHUD() -> { speed, gear, rpm, drift, damage }
 *    sim.dispose()
 * ===================================================================== */

export type CameraMode = "chase" | "hood" | "orbit" | "cinematic";

export interface HUDState {
  speed: number; // km/h (absolute)
  gear: string; // "D" | "R" | "N"
  rpm: number; // 0..1
  drift: number; // lateral slip magnitude (for drift indicator)
  damage: number; // 0..1 accumulated deformation
  airborne: boolean;
}

export interface SimInput {
  throttle: number; // 0..1
  brake: number; // 0..1 (also reverse when stopped)
  steer: number; // -1..1
  handbrake: boolean;
  reset: boolean;
}

// ---- tunables ----------------------------------------------------------
const ENGINE_POWER = 38; // forward accel units/s^2 at full throttle
const BRAKE_POWER = 60;
const MAX_SPEED = 52; // ~187 km/h in sim units (1 unit ≈ 1 m)
const MAX_REVERSE = 16;
const DRAG = 0.42; // linear drag per second
const ROLL_RESIST = 1.1;
const STEER_RATE = 2.6; // rad/s at full lock
const GRIP = 9.5; // lateral velocity kill rate (higher = more grip)
const HANDBRAKE_GRIP = 1.1; // drift grip
const WHEEL_BASE = 2.6;
const CAR_MASS_VISUAL = 1; // visual only

const DEFORM_RADIUS = 3.2; // how wide a dent spreads (local units)
const DEFORM_MAX = 0.85; // max inward push per impact
const DEFORM_HARD_CAP = 1.4; // absolute cap per vertex

// car palette
const CAR_COLORS: { name: string; body: number; accent: number }[] = [
  { name: "Inferno Red", body: 0xd33b3b, accent: 0x2a2a2a },
  { name: "Midnight", body: 0x222831, accent: 0x111111 },
  { name: "Forest", body: 0x2f7d4f, accent: 0x16351f },
  { name: "Sunburst", body: 0xe8a13a, accent: 0x6e3b12 },
  { name: "Arctic", body: 0xeef2f7, accent: 0x9aa3ad },
  { name: "Grape", body: 0x6b3fa0, accent: 0x2b1745 },
];

interface Obstacle {
  mesh: THREE.Object3D;
  // axis-aligned box in world space (XZ plane, y up)
  min: THREE.Vector3;
  max: THREE.Vector3;
  kind: "wall" | "ramp" | "pillar" | "block";
  // for ramps, the up-ramp direction & slope
  height?: number;
}

interface Deformable {
  mesh: THREE.Mesh;
  orig: Float32Array; // original local positions
  cur: Float32Array; // current positions
  amount: Float32Array; // accumulated deformation per vertex (for capping)
}

interface Particle {
  pos: THREE.Vector3;
  vel: THREE.Vector3;
  life: number;
  maxLife: number;
  size: number;
  color: THREE.Color;
  kind: "dust" | "smoke" | "spark";
}

export class CarSim {
  // three core
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private clock = new THREE.Clock();
  private rafId = 0;
  private disposed = false;

  // world
  private sun!: THREE.DirectionalLight;
  private hemi!: THREE.HemisphereLight;
  private ambient!: THREE.AmbientLight;
  private ground!: THREE.Mesh;
  private car!: THREE.Group;
  private wheelFL!: THREE.Mesh;
  private wheelFR!: THREE.Mesh;
  private wheelRL!: THREE.Mesh;
  private wheelRR!: THREE.Mesh;
  private steerPivotFL!: THREE.Group;
  private steerPivotFR!: THREE.Group;
  private brakeLightL!: THREE.Mesh;
  private brakeLightR!: THREE.Mesh;
  private headlightL!: THREE.SpotLight;
  private headlightR!: THREE.SpotLight;
  private bodyMaterial!: THREE.MeshStandardMaterial;
  private accentMaterial!: THREE.MeshStandardMaterial;

  // deformables
  private deformables: Deformable[] = [];
  private totalDeform = 0; // running measure for damage %

  // obstacles
  private obstacles: Obstacle[] = [];
  private WORLD_SIZE = 240; // half-extent of drivable area

  // car physics state
  private pos = new THREE.Vector3(0, 0, 0);
  private vel = new THREE.Vector3(0, 0, 0);
  private heading = 0; // radians, 0 = +Z
  private yawRate = 0;
  private wheelSpin = 0;
  private steerVisual = 0;
  private airborne = false;
  private yVel = 0;
  private yHeight = 0;

  // camera
  private cameraMode: CameraMode = "chase";
  private camPos = new THREE.Vector3();
  private camTarget = new THREE.Vector3();
  private orbitAngle = 0;
  private orbitHeight = 3.2;
  private orbitDist = 9;
  private cineTime = 0;

  // particles
  private particles: Particle[] = [];
  private particlePoints!: THREE.Points;
  private particleGeo!: THREE.BufferGeometry;
  private particleVel: Float32Array = new Float32Array(0);
  private particleLife: Float32Array = new Float32Array(0);
  private particleMax: number = 1200;
  private particleCursor = 0;

  // skid marks
  private skidGroup!: THREE.Group;
  private skidMat!: THREE.MeshBasicMaterial;
  private lastSkidPosL?: THREE.Vector3;
  private lastSkidPosR?: THREE.Vector3;

  // night
  private night = false;

  // input (mutated by React layer)
  public input: SimInput = {
    throttle: 0,
    brake: 0,
    steer: 0,
    handbrake: false,
    reset: false,
  };

  // color
  private colorIdx = 0;

  constructor(canvas: HTMLCanvasElement) {
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: "high-performance",
    });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.setSize(window.innerWidth, window.innerHeight);
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.05;

    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x9ec5e8);
    this.scene.fog = new THREE.FogExp2(0x9ec5e8, 0.0042);

    this.camera = new THREE.PerspectiveCamera(
      62,
      window.innerWidth / window.innerHeight,
      0.1,
      2000
    );
    this.camera.position.set(0, 8, -12);

    this.buildLights();
    this.buildGround();
    this.buildObstacles();
    this.buildCar();
    this.buildParticles();
    this.buildSkidSystem();

    window.addEventListener("resize", this.onResize);
    this.clock.start();
    this.animate();
  }

  // ---------------------------------------------------------------- lights
  private buildLights() {
    this.ambient = new THREE.AmbientLight(0xffffff, 0.35);
    this.scene.add(this.ambient);

    this.hemi = new THREE.HemisphereLight(0xcfe8ff, 0x55603a, 0.7);
    this.scene.add(this.hemi);

    this.sun = new THREE.DirectionalLight(0xfff4e0, 2.1);
    this.sun.position.set(60, 90, 30);
    this.sun.castShadow = true;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.sun.shadow.camera.near = 1;
    this.sun.shadow.camera.far = 260;
    const s = 60;
    this.sun.shadow.camera.left = -s;
    this.sun.shadow.camera.right = s;
    this.sun.shadow.camera.top = s;
    this.sun.shadow.camera.bottom = -s;
    this.sun.shadow.bias = -0.0004;
    this.scene.add(this.sun);
    this.scene.add(this.sun.target);
  }

  // ---------------------------------------------------------------- ground
  private buildGround() {
    // procedural canvas texture: grass + road grid + lane markings
    const tex = this.makeGroundTexture(2048, 2048);
    tex.wrapS = tex.wrapT = THREE.RepeatWrapping;
    tex.repeat.set(8, 8);
    tex.anisotropy = this.renderer.capabilities.getMaxAnisotropy();

    const geo = new THREE.PlaneGeometry(2000, 2000, 1, 1);
    geo.rotateX(-Math.PI / 2);
    const mat = new THREE.MeshStandardMaterial({
      map: tex,
      roughness: 0.95,
      metalness: 0.0,
    });
    this.ground = new THREE.Mesh(geo, mat);
    this.ground.receiveShadow = true;
    this.scene.add(this.ground);

    // subtle ground fog plane edge ring (visual horizon softener) — skip, fog handles it
  }

  private makeGroundTexture(w: number, h: number): THREE.CanvasTexture {
    const c = document.createElement("canvas");
    c.width = w;
    c.height = h;
    const ctx = c.getContext("2d")!;

    // grass base with mottling
    ctx.fillStyle = "#3f6b3a";
    ctx.fillRect(0, 0, w, h);
    for (let i = 0; i < 9000; i++) {
      const x = Math.random() * w;
      const y = Math.random() * h;
      const r = 2 + Math.random() * 6;
      const shade = Math.random();
      ctx.fillStyle =
        shade > 0.5
          ? `rgba(70,110,55,0.5)`
          : `rgba(50,85,42,0.5)`;
      ctx.beginPath();
      ctx.arc(x, y, r, 0, Math.PI * 2);
      ctx.fill();
    }

    // road grid: a road every cell, centered. We draw 2 perpendicular roads.
    const roadW = w * 0.16;
    ctx.fillStyle = "#2b2b30";
    ctx.fillRect(w / 2 - roadW / 2, 0, roadW, h); // vertical road
    ctx.fillRect(0, h / 2 - roadW / 2, w, roadW); // horizontal road

    // lane dashes (yellow)
    ctx.strokeStyle = "rgba(240,210,80,0.85)";
    ctx.lineWidth = w * 0.012;
    ctx.setLineDash([w * 0.03, w * 0.03]);
    ctx.beginPath();
    ctx.moveTo(w / 2, 0);
    ctx.lineTo(w / 2, h);
    ctx.moveTo(0, h / 2);
    ctx.lineTo(w, h / 2);
    ctx.stroke();
    ctx.setLineDash([]);

    // road edge lines (white)
    ctx.strokeStyle = "rgba(230,230,230,0.5)";
    ctx.lineWidth = w * 0.006;
    ctx.beginPath();
    ctx.moveTo(w / 2 - roadW / 2, 0);
    ctx.lineTo(w / 2 - roadW / 2, h);
    ctx.moveTo(w / 2 + roadW / 2, 0);
    ctx.lineTo(w / 2 + roadW / 2, h);
    ctx.moveTo(0, h / 2 - roadW / 2);
    ctx.lineTo(w, h / 2 - roadW / 2);
    ctx.moveTo(0, h / 2 + roadW / 2);
    ctx.lineTo(w, h / 2 + roadW / 2);
    ctx.stroke();

    return new THREE.CanvasTexture(c);
  }

  // ------------------------------------------------------------ obstacles
  private buildObstacles() {
    const concreteMat = new THREE.MeshStandardMaterial({
      color: 0xb9b2a7,
      roughness: 0.9,
      metalness: 0.0,
    });
    const crateMat = new THREE.MeshStandardMaterial({
      color: 0x9c6b3a,
      roughness: 0.85,
      metalness: 0.0,
    });
    const pillarMat = new THREE.MeshStandardMaterial({
      color: 0x6b7079,
      roughness: 0.6,
      metalness: 0.3,
    });

    const addBox = (
      x: number,
      z: number,
      sx: number,
      sy: number,
      sz: number,
      mat: THREE.Material,
      kind: Obstacle["kind"]
    ) => {
      const geo = new THREE.BoxGeometry(sx, sy, sz);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.set(x, sy / 2, z);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.scene.add(mesh);
      this.obstacles.push({
        mesh,
        min: new THREE.Vector3(x - sx / 2, 0, z - sz / 2),
        max: new THREE.Vector3(x + sx / 2, sy, z + sz / 2),
        kind,
      });
    };

    // a ring of walls + scatter of blocks and pillars around the test track
    // perimeter boundary walls (so you can't fall off the world)
    const wallH = 3;
    const wallT = 2;
    addBox(0, this.WORLD_SIZE, this.WORLD_SIZE * 2, wallH, wallT, concreteMat, "wall");
    addBox(0, -this.WORLD_SIZE, this.WORLD_SIZE * 2, wallH, wallT, concreteMat, "wall");
    addBox(this.WORLD_SIZE, 0, wallT, wallH, this.WORLD_SIZE * 2, concreteMat, "wall");
    addBox(-this.WORLD_SIZE, 0, wallT, wallH, this.WORLD_SIZE * 2, concreteMat, "wall");

    // scattered crate stacks
    const cratePositions: [number, number][] = [
      [40, 40], [-50, 30], [-30, -55], [60, -40], [80, 20],
      [-80, -20], [25, -70], [-65, 70], [95, 75], [-95, -80],
    ];
    for (const [x, z] of cratePositions) {
      const base = 1.6;
      const h = base * (1 + Math.floor(Math.random() * 2));
      addBox(x, z, base * 2, h, base * 2, crateMat, "block");
      // little stack on top sometimes
      if (Math.random() > 0.4) {
        addBox(x + (Math.random() - 0.5), z + (Math.random() - 0.5), base, base, base, crateMat, "block");
      }
    }

    // pillars
    const pillarPositions: [number, number][] = [
      [20, 90], [-20, 90], [20, -90], [-20, -90],
      [120, 0], [-120, 0], [0, 130], [0, -130],
    ];
    for (const [x, z] of pillarPositions) {
      addBox(x, z, 2.4, 7, 2.4, pillarMat, "pillar");
    }

    // a jump ramp
    this.addRamp(0, -120, 14, 8, 2.6, concreteMat);
    this.addRamp(-130, 40, 12, 7, 2.2, concreteMat);
  }

  private addRamp(
    x: number,
    z: number,
    width: number,
    length: number,
    height: number,
    mat: THREE.Material
  ) {
    // A wedge: a box rotated. We approximate as a low box with a sloped top via geometry.
    const geo = new THREE.BoxGeometry(width, height, length);
    // reshape top face into a slope by moving back-top vertices up
    const pos = geo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const y = pos.getY(i);
      const zz = pos.getZ(i); // local Z
      if (y > 0) {
        // back of ramp (negative local Z) stays low, front (positive Z) rises... we slope it
        const t = (zz + length / 2) / length; // 0..1
        pos.setY(i, height * t);
      }
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
    const mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, 0, z);
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    this.scene.add(mesh);
    // collision: treat ramp as a box of full height for the front half so the car climbs it
    this.obstacles.push({
      mesh,
      min: new THREE.Vector3(x - width / 2, 0, z - length / 2),
      max: new THREE.Vector3(x + width / 2, height, z + length / 2),
      kind: "ramp",
      height,
    });
  }

  // ------------------------------------------------------------------ car
  private buildCar() {
    this.car = new THREE.Group();

    this.bodyMaterial = new THREE.MeshStandardMaterial({
      color: CAR_COLORS[0].body,
      roughness: 0.35,
      metalness: 0.55,
      envMapIntensity: 1.0,
    });
    this.accentMaterial = new THREE.MeshStandardMaterial({
      color: CAR_COLORS[0].accent,
      roughness: 0.5,
      metalness: 0.4,
    });
    const glassMat = new THREE.MeshStandardMaterial({
      color: 0x10131a,
      roughness: 0.1,
      metalness: 0.9,
      transparent: true,
      opacity: 0.65,
    });
    const tireMat = new THREE.MeshStandardMaterial({
      color: 0x111111,
      roughness: 0.85,
      metalness: 0.1,
    });
    const rimMat = new THREE.MeshStandardMaterial({
      color: 0xcfd4da,
      roughness: 0.3,
      metalness: 0.85,
    });
    const lightMat = new THREE.MeshStandardMaterial({
      color: 0xfff6cf,
      emissive: 0xfff0c0,
      emissiveIntensity: 1.2,
      roughness: 0.2,
      metalness: 0.1,
    });
    const brakeMat = new THREE.MeshStandardMaterial({
      color: 0x551111,
      emissive: 0x550000,
      emissiveIntensity: 0.3,
      roughness: 0.4,
      metalness: 0.3,
    });

    // ---- main body (lower, wider) — DEFORMABLE ----
    const bodyGeo = new THREE.BoxGeometry(2.0, 0.7, 4.4, 8, 4, 14);
    this.roundBoxGeo(bodyGeo, 0.12);
    const body = new THREE.Mesh(bodyGeo, this.bodyMaterial);
    body.position.set(0, 0.55, 0);
    body.castShadow = true;
    body.receiveShadow = true;
    this.car.add(body);
    this.registerDeformable(body);

    // ---- cabin / roof — DEFORMABLE ----
    const cabinGeo = new THREE.BoxGeometry(1.78, 0.62, 2.2, 6, 3, 10);
    this.roundBoxGeo(cabinGeo, 0.14);
    // taper the cabin (roof narrower at top)
    {
      const p = cabinGeo.attributes.position;
      for (let i = 0; i < p.count; i++) {
        if (p.getY(i) > 0) {
          p.setX(i, p.getX(i) * 0.78);
          p.setZ(i, p.getZ(i) * 0.92);
        }
      }
      p.needsUpdate = true;
      cabinGeo.computeVertexNormals();
    }
    const cabin = new THREE.Mesh(cabinGeo, this.bodyMaterial);
    cabin.position.set(0, 1.18, -0.15);
    cabin.castShadow = true;
    cabin.receiveShadow = true;
    this.car.add(cabin);
    this.registerDeformable(cabin);

    // ---- windows (glass shell around cabin, slightly larger, dark) ----
    const glassGeo = new THREE.BoxGeometry(1.82, 0.5, 2.26, 1, 1, 1);
    const glass = new THREE.Mesh(glassGeo, glassMat);
    glass.position.set(0, 1.2, -0.15);
    this.car.add(glass);

    // ---- hood accent strip ----
    const hoodGeo = new THREE.BoxGeometry(0.2, 0.04, 1.6);
    const hood = new THREE.Mesh(hoodGeo, this.accentMaterial);
    hood.position.set(0, 0.92, 1.0);
    this.car.add(hood);

    // ---- bumpers ----
    const bumperGeo = new THREE.BoxGeometry(2.05, 0.28, 0.3);
    const fBumper = new THREE.Mesh(bumperGeo, this.accentMaterial);
    fBumper.position.set(0, 0.5, 2.25);
    fBumper.castShadow = true;
    this.car.add(fBumper);
    const rBumper = new THREE.Mesh(bumperGeo, this.accentMaterial);
    rBumper.position.set(0, 0.5, -2.25);
    rBumper.castShadow = true;
    this.car.add(rBumper);

    // ---- side skirts ----
    const skirtGeo = new THREE.BoxGeometry(0.12, 0.18, 3.6);
    const skirtL = new THREE.Mesh(skirtGeo, this.accentMaterial);
    skirtL.position.set(1.0, 0.34, 0);
    this.car.add(skirtL);
    const skirtR = new THREE.Mesh(skirtGeo, this.accentMaterial);
    skirtR.position.set(-1.0, 0.34, 0);
    this.car.add(skirtR);

    // ---- headlights ----
    const hlGeo = new THREE.BoxGeometry(0.42, 0.2, 0.08);
    const hlL = new THREE.Mesh(hlGeo, lightMat);
    hlL.position.set(0.62, 0.62, 2.22);
    this.car.add(hlL);
    const hlR = new THREE.Mesh(hlGeo, lightMat);
    hlR.position.set(-0.62, 0.62, 2.22);
    this.car.add(hlR);

    // actual spotlights for night
    this.headlightL = new THREE.SpotLight(0xfff2d0, 0, 60, Math.PI / 6, 0.4, 1.5);
    this.headlightL.position.set(0.62, 0.62, 2.2);
    this.headlightL.target.position.set(0.62, 0.4, 14);
    this.car.add(this.headlightL);
    this.car.add(this.headlightL.target);
    this.headlightR = new THREE.SpotLight(0xfff2d0, 0, 60, Math.PI / 6, 0.4, 1.5);
    this.headlightR.position.set(-0.62, 0.62, 2.2);
    this.headlightR.target.position.set(-0.62, 0.4, 14);
    this.car.add(this.headlightR);
    this.car.add(this.headlightR.target);

    // ---- taillights (brake lights) ----
    const tlGeo = new THREE.BoxGeometry(0.5, 0.18, 0.08);
    this.brakeLightL = new THREE.Mesh(tlGeo, brakeMat.clone());
    this.brakeLightL.position.set(0.6, 0.62, -2.22);
    this.car.add(this.brakeLightL);
    this.brakeLightR = new THREE.Mesh(tlGeo, brakeMat.clone());
    this.brakeLightR.position.set(-0.6, 0.62, -2.22);
    this.car.add(this.brakeLightR);

    // ---- wheels ----
    const wheelGeo = new THREE.CylinderGeometry(0.5, 0.5, 0.34, 24);
    wheelGeo.rotateZ(Math.PI / 2); // axle along X
    const rimGeo = new THREE.CylinderGeometry(0.26, 0.26, 0.36, 8);
    rimGeo.rotateZ(Math.PI / 2);
    const makeWheel = (x: number, z: number, steering: boolean) => {
      const g = new THREE.Group();
      const w = new THREE.Mesh(wheelGeo, tireMat);
      w.castShadow = true;
      g.add(w);
      const rim = new THREE.Mesh(rimGeo, rimMat);
      g.add(rim);
      // spokes
      for (let s = 0; s < 5; s++) {
        const spoke = new THREE.Mesh(
          new THREE.BoxGeometry(0.08, 0.42, 0.05),
          rimMat
        );
        spoke.rotation.x = (s / 5) * Math.PI * 2;
        g.add(spoke);
      }
      g.position.set(x, 0.5, z);
      if (steering) {
        // wrap in a steering pivot
        const pivot = new THREE.Group();
        pivot.position.set(x, 0.5, z);
        g.position.set(0, 0, 0);
        pivot.add(g);
        this.car.add(pivot);
        return { pivot, wheel: g };
      }
      this.car.add(g);
      return { pivot: null as THREE.Group | null, wheel: g };
    };

    const fl = makeWheel(1.05, 1.45, true);
    const fr = makeWheel(-1.05, 1.45, true);
    const rl = makeWheel(1.05, -1.45, false);
    const rr = makeWheel(-1.05, -1.45, false);
    this.steerPivotFL = fl.pivot!;
    this.steerPivotFR = fr.pivot!;
    this.wheelFL = fl.wheel;
    this.wheelFR = fr.wheel;
    this.wheelRL = rl.wheel;
    this.wheelRR = rr.wheel;

    // place car at start
    this.pos.set(0, 0, 0);
    this.heading = 0;
    this.car.position.copy(this.pos);
    this.car.rotation.y = this.heading;

    this.scene.add(this.car);

    // a faint contact shadow blob under car (cheap)
    const blobGeo = new THREE.CircleGeometry(1.7, 24);
    blobGeo.rotateX(-Math.PI / 2);
    const blobMat = new THREE.MeshBasicMaterial({
      color: 0x000000,
      transparent: true,
      opacity: 0.28,
      depthWrite: false,
    });
    const blob = new THREE.Mesh(blobGeo, blobMat);
    blob.position.set(0, 0.02, 0);
    this.car.add(blob);
  }

  // soften box edges by pushing outer vertices inward with a bevel
  private roundBoxGeo(geo: THREE.BoxGeometry, radius: number) {
    const pos = geo.attributes.position;
    const half = {
      x: (geo.parameters as any).width / 2,
      y: (geo.parameters as any).height / 2,
      z: (geo.parameters as any).depth / 2,
    };
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const y = pos.getY(i);
      const z = pos.getZ(i);
      // distance from corner
      const ax = Math.abs(x) - (half.x - radius);
      const ay = Math.abs(y) - (half.y - radius);
      const az = Math.abs(z) - (half.z - radius);
      // if outside the inner rounded region, pull toward corner along the soft axis
      // Simple rounded effect: clamp extremes and bias slightly inward
      if (ax > 0 && ay > 0 && az > 0) {
        const len = Math.sqrt(ax * ax + ay * ay + az * az);
        if (len > radius) {
          const k = radius / len;
          pos.setXYZ(
            i,
            Math.sign(x) * (half.x - radius + ax * k),
            Math.sign(y) * (half.y - radius + ay * k),
            Math.sign(z) * (half.z - radius + az * k)
          );
        }
      }
    }
    pos.needsUpdate = true;
    geo.computeVertexNormals();
  }

  private registerDeformable(mesh: THREE.Mesh) {
    const geo = mesh.geometry as THREE.BufferGeometry;
    const orig = Float32Array.from(geo.attributes.position.array as Float32Array);
    const cur = Float32Array.from(orig);
    const amount = new Float32Array(orig.length / 3);
    this.deformables.push({ mesh, orig, cur, amount });
  }

  // ------------------------------------------------------------ particles
  private buildParticles() {
    this.particleGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(this.particleMax * 3);
    const colors = new Float32Array(this.particleMax * 3);
    const sizes = new Float32Array(this.particleMax);
    this.particleVel = new Float32Array(this.particleMax * 3);
    this.particleLife = new Float32Array(this.particleMax);
    this.particleGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    this.particleGeo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    this.particleGeo.setAttribute("size", new THREE.BufferAttribute(sizes, 1));

    const mat = new THREE.PointsMaterial({
      size: 1.0,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      depthWrite: false,
      sizeAttenuation: true,
      blending: THREE.NormalBlending,
    });
    this.particlePoints = new THREE.Points(this.particleGeo, mat);
    this.particlePoints.frustumCulled = false;
    this.scene.add(this.particlePoints);

    // init particle pool
    for (let i = 0; i < this.particleMax; i++) {
      this.particles.push({
        pos: new THREE.Vector3(),
        vel: new THREE.Vector3(),
        life: 0,
        maxLife: 1,
        size: 0,
        color: new THREE.Color(),
        kind: "dust",
      });
    }
  }

  private spawnParticle(
    px: number,
    py: number,
    pz: number,
    vx: number,
    vy: number,
    vz: number,
    life: number,
    size: number,
    color: THREE.Color,
    kind: Particle["kind"]
  ) {
    const p = this.particles[this.particleCursor];
    p.pos.set(px, py, pz);
    p.vel.set(vx, vy, vz);
    p.life = life;
    p.maxLife = life;
    p.size = size;
    p.color.copy(color);
    p.kind = kind;
    this.particleCursor = (this.particleCursor + 1) % this.particleMax;
  }

  private updateParticles(dt: number) {
    const posAttr = this.particleGeo.attributes.position as THREE.BufferAttribute;
    const colAttr = this.particleGeo.attributes.color as THREE.BufferAttribute;
    const sizeAttr = this.particleGeo.attributes.size as THREE.BufferAttribute;
    const pos = posAttr.array as Float32Array;
    const col = colAttr.array as Float32Array;
    const sz = sizeAttr.array as Float32Array;

    for (let i = 0; i < this.particleMax; i++) {
      const p = this.particles[i];
      if (p.life <= 0) {
        // hide
        sz[i] = 0;
        continue;
      }
      p.life -= dt;
      // integrate
      p.vel.y -= 9.8 * dt * (p.kind === "spark" ? 0.5 : 0.2);
      p.vel.multiplyScalar(1 - 1.5 * dt); // air drag
      p.pos.addScaledVector(p.vel, dt);
      if (p.kind !== "spark" && p.pos.y < 0.05) {
        p.pos.y = 0.05;
        p.vel.y = 0;
        p.vel.x *= 0.6;
        p.vel.z *= 0.6;
      }
      const t = Math.max(0, p.life / p.maxLife);
      pos[i * 3] = p.pos.x;
      pos[i * 3 + 1] = p.pos.y;
      pos[i * 3 + 2] = p.pos.z;
      // fade color toward end
      const fade = p.kind === "spark" ? t : 0.4 + t * 0.6;
      col[i * 3] = p.color.r * fade;
      col[i * 3 + 1] = p.color.g * fade;
      col[i * 3 + 2] = p.color.b * fade;
      sz[i] = p.size * (p.kind === "smoke" ? 1 + (1 - t) * 1.6 : t * 0.9 + 0.1);
    }
    posAttr.needsUpdate = true;
    colAttr.needsUpdate = true;
    sizeAttr.needsUpdate = true;
  }

  // ----------------------------------------------------------- skid marks
  private buildSkidSystem() {
    this.skidGroup = new THREE.Group();
    this.skidMat = new THREE.MeshBasicMaterial({
      color: 0x111111,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    });
    this.skidGroup.frustumCulled = false;
    this.scene.add(this.skidGroup);
  }

  private addSkidSegment(p: THREE.Vector3, dir: THREE.Vector3, width: number) {
    // a tiny quad stretched along dir
    const len = dir.length();
    if (len < 0.001) return;
    const geo = new THREE.PlaneGeometry(width, len);
    geo.rotateX(-Math.PI / 2);
    const m = new THREE.Mesh(geo, this.skidMat);
    m.position.copy(p).addScaledVector(dir, 0.5);
    m.position.y = 0.03;
    m.rotation.y = Math.atan2(dir.x, dir.z);
    this.skidGroup.add(m);
    // cap group size to keep perf in check
    if (this.skidGroup.children.length > 600) {
      const old = this.skidGroup.children[0];
      this.skidGroup.remove(old);
      (old as THREE.Mesh).geometry.dispose();
    }
  }

  // ----------------------------------------------------------- public API
  public setColor(idx: number) {
    this.colorIdx = idx % CAR_COLORS.length;
    const c = CAR_COLORS[this.colorIdx];
    this.bodyMaterial.color.setHex(c.body);
    this.accentMaterial.color.setHex(c.accent);
  }

  public setCameraMode(mode: CameraMode) {
    this.cameraMode = mode;
  }

  public setNight(on: boolean) {
    this.night = on;
    if (on) {
      this.scene.background = new THREE.Color(0x0a0f1e);
      if (this.scene.fog instanceof THREE.FogExp2) {
        this.scene.fog.color.set(0x0a0f1e);
        this.scene.fog.density = 0.012;
      }
      this.ambient.intensity = 0.18;
      this.hemi.intensity = 0.25;
      this.sun.intensity = 0.25;
      this.sun.color.set(0x6f86c9);
      this.headlightL.intensity = 3;
      this.headlightR.intensity = 3;
    } else {
      this.scene.background = new THREE.Color(0x9ec5e8);
      if (this.scene.fog instanceof THREE.FogExp2) {
        this.scene.fog.color.set(0x9ec5e8);
        this.scene.fog.density = 0.0042;
      }
      this.ambient.intensity = 0.35;
      this.hemi.intensity = 0.7;
      this.sun.intensity = 2.1;
      this.sun.color.set(0xfff4e0);
      this.headlightL.intensity = 0;
      this.headlightR.intensity = 0;
    }
  }

  public resetCar() {
    this.pos.set(0, 0, 0);
    this.vel.set(0, 0, 0);
    this.heading = 0;
    this.yawRate = 0;
    this.yVel = 0;
    this.yHeight = 0;
    this.airborne = false;
    this.totalDeform = 0;
    // restore deformables
    for (const d of this.deformables) {
      d.cur.set(d.orig);
      d.amount.fill(0);
      const g = d.mesh.geometry as THREE.BufferGeometry;
      (g.attributes.position as THREE.BufferAttribute).copyArray(d.orig);
      (g.attributes.position as THREE.BufferAttribute).needsUpdate = true;
      g.computeVertexNormals();
    }
    // clear skids
    for (const ch of [...this.skidGroup.children]) {
      this.skidGroup.remove(ch);
      (ch as THREE.Mesh).geometry.dispose();
    }
  }

  public getCarColors() {
    return CAR_COLORS.map((c, i) => ({ idx: i, name: c.name, hex: c.body }));
  }

  public getHUD(): HUDState {
    const speed = this.vel.length();
    const forward = new THREE.Vector3(Math.sin(this.heading), 0, Math.cos(this.heading));
    const vForward = this.vel.dot(forward);
    const kmh = Math.abs(vForward) * 3.6;
    let gear = "N";
    if (vForward > 0.5) gear = "D";
    else if (vForward < -0.5) gear = "R";
    const rpm = Math.min(1, speed / MAX_SPEED + this.input.throttle * 0.2);
    const right = new THREE.Vector3(Math.cos(this.heading), 0, -Math.sin(this.heading));
    const drift = Math.abs(this.vel.dot(right));
    return {
      speed: kmh,
      gear,
      rpm,
      drift,
      damage: Math.min(1, this.totalDeform / 60),
      airborne: this.airborne,
    };
  }

  // -------------------------------------------------------------- update
  private animate = () => {
    if (this.disposed) return;
    this.rafId = requestAnimationFrame(this.animate);
    const dt = Math.min(this.clock.getDelta(), 0.05);
    this.step(dt);
    this.renderer.render(this.scene, this.camera);
  };

  private step(dt: number) {
    if (this.input.reset) {
      this.resetCar();
      this.input.reset = false;
    }

    this.updatePhysics(dt);
    this.updateCarVisual(dt);
    this.updateCamera(dt);
    this.updateParticles(dt);
    this.updateSkids(dt);
    this.updateLights();
  }

  private updatePhysics(dt: number) {
    const forward = new THREE.Vector3(Math.sin(this.heading), 0, Math.cos(this.heading));
    const right = new THREE.Vector3(Math.cos(this.heading), 0, -Math.sin(this.heading));

    // decompose velocity into forward & lateral
    let vForward = this.vel.dot(forward);
    let vRight = this.vel.dot(right);

    // throttle / brake / reverse
    if (this.input.throttle > 0) {
      vForward += ENGINE_POWER * this.input.throttle * dt;
    }
    if (this.input.brake > 0) {
      if (vForward > 0.5) {
        // braking
        vForward -= BRAKE_POWER * this.input.brake * dt;
        if (vForward < 0) vForward = 0;
      } else {
        // reverse
        vForward -= ENGINE_POWER * 0.55 * this.input.brake * dt;
        if (vForward < -MAX_REVERSE) vForward = -MAX_REVERSE;
      }
    }

    // rolling resistance + drag (more drag at high speed)
    const speed = Math.abs(vForward);
    const dragForce = ROLL_RESIST + DRAG * speed * 0.04 * speed;
    if (vForward > 0) {
      vForward -= Math.min(vForward, dragForce * dt);
    } else if (vForward < 0) {
      vForward += Math.min(-vForward, dragForce * dt * 0.6);
    }
    // clamp
    vForward = Math.max(-MAX_REVERSE, Math.min(MAX_SPEED, vForward));

    // steering — effective at speed, reduced at very low speed, reversed when reversing
    const speedFactor = Math.min(1, speed / 6);
    const steerDir = vForward < -0.2 ? -1 : 1;
    const targetYaw = this.input.steer * STEER_RATE * speedFactor * steerDir;
    // smooth steering
    this.yawRate += (targetYaw - this.yawRate) * Math.min(1, dt * 8);
    this.heading += this.yawRate * dt;

    // lateral grip
    const grip = this.input.handbrake ? HANDBRAKE_GRIP : GRIP;
    vRight *= Math.exp(-grip * dt);

    // recombine velocity (recompute forward/right after heading change for next frame)
    const newForward = new THREE.Vector3(Math.sin(this.heading), 0, Math.cos(this.heading));
    const newRight = new THREE.Vector3(Math.cos(this.heading), 0, -Math.sin(this.heading));
    this.vel.copy(newForward).multiplyScalar(vForward).addScaledVector(newRight, vRight);

    // integrate position (XZ)
    this.pos.addScaledVector(this.vel, dt);

    // vertical (ramps / jumps)
    this.handleVertical(dt);

    // world bounds (soft)
    const lim = this.WORLD_SIZE - 2;
    if (this.pos.x > lim) { this.pos.x = lim; this.vel.x *= -0.3; }
    if (this.pos.x < -lim) { this.pos.x = -lim; this.vel.x *= -0.3; }
    if (this.pos.z > lim) { this.pos.z = lim; this.vel.z *= -0.3; }
    if (this.pos.z < -lim) { this.pos.z = -lim; this.vel.z *= -0.3; }

    // collisions with obstacles
    this.handleCollisions(forward, vForward);

    // wheel spin & steering visuals
    this.wheelSpin += vForward * dt / 0.5;
    this.steerVisual += (this.input.steer * 0.5 - this.steerVisual) * Math.min(1, dt * 10);
  }

  private handleVertical(dt: number) {
    // ramp support: check if car is over a ramp and lift accordingly
    let groundY = 0;
    for (const o of this.obstacles) {
      if (o.kind !== "ramp") continue;
      if (
        this.pos.x > o.min.x && this.pos.x < o.max.x &&
        this.pos.z > o.min.z && this.pos.z < o.max.z
      ) {
        // slope height based on local Z position within ramp (front rises)
        const t = (this.pos.z - o.min.z) / (o.max.z - o.min.z); // 0..1
        groundY = Math.max(groundY, (o.height || 0) * t);
      }
    }

    // simple vertical physics
    const targetY = groundY;
    if (this.yHeight < targetY) {
      // resting on ramp
      this.yHeight = targetY;
      this.yVel = Math.max(0, this.yVel);
    } else {
      // gravity
      this.yVel -= 22 * dt;
      this.yHeight += this.yVel * dt;
      if (this.yHeight < targetY) {
        this.yHeight = targetY;
        if (this.yVel < -4) {
          // landing impact — small dust burst
          this.spawnDust(this.pos.x, 0.1, this.pos.z, 12);
        }
        this.yVel = 0;
      }
    }
    this.airborne = this.yHeight > 0.05;
  }

  private handleCollisions(forward: THREE.Vector3, vForward: number) {
    // approximate car as an AABB in XZ of half-extents
    const halfX = 1.05;
    const halfZ = 2.2;
    // car's axis-aligned bounds (approx, using world XZ)
    const cMin = new THREE.Vector3(this.pos.x - halfX, 0, this.pos.z - halfZ);
    const cMax = new THREE.Vector3(this.pos.x + halfX, 0, this.pos.z + halfZ);

    for (const o of this.obstacles) {
      if (o.kind === "ramp") continue; // handled by vertical
      // AABB overlap test in XZ
      if (
        cMax.x > o.min.x && cMin.x < o.max.x &&
        cMax.z > o.min.z && cMin.z < o.max.z
      ) {
        // compute penetration on each axis, push out along min
        const penX = Math.min(cMax.x - o.min.x, o.max.x - cMin.x);
        const penZ = Math.min(cMax.z - o.min.z, o.max.z - cMin.z);
        let nx = 0;
        let nz = 0;
        let pen = 0;
        if (penX < penZ) {
          // resolve along X
          pen = penX;
          nx = this.pos.x < (o.min.x + o.max.x) / 2 ? -1 : 1;
          this.pos.x += nx * pen;
        } else {
          pen = penZ;
          nz = this.pos.z < (o.min.z + o.max.z) / 2 ? -1 : 1;
          this.pos.z += nz * pen;
        }
        const normal = new THREE.Vector3(nx, 0, nz).normalize();
        // impact speed along normal
        const vAlongN = this.vel.dot(normal);
        const impactSpeed = -vAlongN; // how fast into the wall
        if (impactSpeed > 1.5) {
          // bounce + damage
          const restitution = 0.18;
          this.vel.addScaledVector(normal, impactSpeed * (1 + restitution));
          // also bleed lateral
          this.vel.multiplyScalar(0.82);
          // trigger softbody deformation at impact point
          this.applyDeformation(normal, Math.min(impactSpeed, 30));
          // sparks if fast
          if (impactSpeed > 6) {
            this.spawnSparks(
              this.pos.x - nx * halfX * 0.6,
              0.7,
              this.pos.z - nz * halfZ * 0.6,
              normal,
              impactSpeed
            );
          }
          // camera shake handled by camTarget micro-jitter — skip
        } else {
          // gentle touch, just stop into wall
          this.vel.addScaledVector(normal, -vAlongN * 0.6);
        }
        // recompute bounds after push for next obstacles
        cMin.set(this.pos.x - halfX, 0, this.pos.z - halfZ);
        cMax.set(this.pos.x + halfX, 0, this.pos.z + halfZ);
      }
    }
  }

  // ---- the softbody-ish deformation ----
  private applyDeformation(normal: THREE.Vector3, impactSpeed: number) {
    // world-space impact point: roughly at car body front/rear/side based on normal
    const localN = normal.clone().applyAxisAngle(new THREE.Vector3(0, 1, 0), -this.heading);
    // impact center on body (in car local space)
    const impactLocal = new THREE.Vector3(
      localN.x * 1.2,
      0.6,
      localN.z * 2.3
    );
    const magnitude = Math.min(DEFORM_MAX, impactSpeed * 0.045);

    for (const d of this.deformables) {
      // transform impact point into this mesh's local space
      const mesh = d.mesh;
      // mesh local = car-local minus mesh position (no scale/rotation on meshes besides car)
      const ml = impactLocal.clone().sub(mesh.position);
      // deformation direction in mesh-local space: push along -localN (into the car)
      const dir = localN.clone().multiplyScalar(-1);
      const posAttr = mesh.geometry.attributes.position as THREE.BufferAttribute;
      const arr = posAttr.array as Float32Array;
      let changed = false;
      for (let i = 0; i < arr.length / 3; i++) {
        const vx = arr[i * 3];
        const vy = arr[i * 3 + 1];
        const vz = arr[i * 3 + 2];
        const dx = vx - ml.x;
        const dy = vy - ml.y;
        const dz = vz - ml.z;
        const dist = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (dist < DEFORM_RADIUS) {
          const falloff = (1 - dist / DEFORM_RADIUS);
          const push = magnitude * falloff * falloff;
          // accumulate, capped
          const aIdx = i;
          if (d.amount[aIdx] + push > DEFORM_HARD_CAP) continue;
          d.amount[aIdx] += push;
          arr[i * 3] += dir.x * push;
          arr[i * 3 + 1] += dir.y * push * 0.4; // less vertical crumple
          arr[i * 3 + 2] += dir.z * push;
          changed = true;
        }
      }
      if (changed) {
        posAttr.needsUpdate = true;
        (mesh.geometry as THREE.BufferGeometry).computeVertexNormals();
        this.totalDeform += magnitude * 6;
      }
    }
  }

  private spawnDust(x: number, y: number, z: number, count: number) {
    const col = new THREE.Color(0xb3956a);
    for (let i = 0; i < count; i++) {
      this.spawnParticle(
        x + (Math.random() - 0.5) * 0.8,
        y + Math.random() * 0.2,
        z + (Math.random() - 0.5) * 0.8,
        (Math.random() - 0.5) * 2,
        Math.random() * 1.2,
        (Math.random() - 0.5) * 2,
        0.6 + Math.random() * 0.5,
        0.5 + Math.random() * 0.5,
        col,
        "dust"
      );
    }
  }

  private spawnSparks(x: number, y: number, z: number, normal: THREE.Vector3, power: number) {
    const col = new THREE.Color(0xffcf6a);
    const count = Math.min(40, Math.floor(power * 3));
    for (let i = 0; i < count; i++) {
      const spread = 0.6;
      this.spawnParticle(
        x, y, z,
        normal.x * (2 + Math.random() * 3) + (Math.random() - 0.5) * spread * 4,
        Math.random() * 4 + 1,
        normal.z * (2 + Math.random() * 3) + (Math.random() - 0.5) * spread * 4,
        0.3 + Math.random() * 0.4,
        0.12 + Math.random() * 0.08,
        col,
        "spark"
      );
    }
  }

  private spawnTireSmoke(x: number, z: number, intensity: number) {
    const col = new THREE.Color(0xcccccc);
    const count = Math.min(4, Math.ceil(intensity));
    for (let i = 0; i < count; i++) {
      this.spawnParticle(
        x + (Math.random() - 0.5) * 0.4,
        0.3 + Math.random() * 0.2,
        z + (Math.random() - 0.5) * 0.4,
        (Math.random() - 0.5) * 1.5,
        0.6 + Math.random() * 0.8,
        (Math.random() - 0.5) * 1.5,
        0.7 + Math.random() * 0.6,
        0.7 + Math.random() * 0.6,
        col,
        "smoke"
      );
    }
  }

  private updateCarVisual(dt: number) {
    this.car.position.set(this.pos.x, this.yHeight, this.pos.z);
    this.car.rotation.y = this.heading;
    // a little body roll & pitch for flavor
    const right = new THREE.Vector3(Math.cos(this.heading), 0, -Math.sin(this.heading));
    const lateral = this.vel.dot(right);
    const forwardSpeed = this.vel.dot(new THREE.Vector3(Math.sin(this.heading), 0, Math.cos(this.heading)));
    const targetRoll = THREE.MathUtils.clamp(-lateral * 0.012, -0.12, 0.12);
    const targetPitch = THREE.MathUtils.clamp(-forwardSpeed * 0.003 - this.input.brake * 0.04 + this.input.throttle * 0.02, -0.08, 0.08);
    this.car.rotation.z += (targetRoll - this.car.rotation.z) * Math.min(1, dt * 6);
    this.car.rotation.x += (targetPitch - this.car.rotation.x) * Math.min(1, dt * 6);

    // wheels spin
    [this.wheelFL, this.wheelFR, this.wheelRL, this.wheelRR].forEach((w) => {
      w.rotation.x = this.wheelSpin;
    });
    // steering pivots
    this.steerPivotFL.rotation.y = this.steerVisual;
    this.steerPivotFR.rotation.y = this.steerVisual;

    // brake lights glow when braking
    const blMatL = this.brakeLightL.material as THREE.MeshStandardMaterial;
    const blMatR = this.brakeLightR.material as THREE.MeshStandardMaterial;
    const brakeGlow = this.input.brake > 0 ? 2.5 : 0.3;
    blMatL.emissiveIntensity += (brakeGlow - blMatL.emissiveIntensity) * Math.min(1, dt * 12);
    blMatR.emissiveIntensity += (brakeGlow - blMatR.emissiveIntensity) * Math.min(1, dt * 12);
  }

  private updateCamera(dt: number) {
    const carPos = new THREE.Vector3(this.pos.x, this.yHeight + 0.6, this.pos.z);
    const forward = new THREE.Vector3(Math.sin(this.heading), 0, Math.cos(this.heading));
    const right = new THREE.Vector3(Math.cos(this.heading), 0, -Math.sin(this.heading));

    if (this.cameraMode === "chase") {
      const desired = carPos.clone()
        .addScaledVector(forward, -7.5)
        .add(new THREE.Vector3(0, 3.4, 0));
      this.camPos.lerp(desired, Math.min(1, dt * 4.5));
      this.camera.position.copy(this.camPos);
      const tgt = carPos.clone().addScaledVector(forward, 5);
      this.camTarget.lerp(tgt, Math.min(1, dt * 6));
      this.camera.lookAt(this.camTarget);
    } else if (this.cameraMode === "hood") {
      const desired = carPos.clone()
        .addScaledVector(forward, 0.4)
        .add(new THREE.Vector3(0, 1.1, 0));
      this.camPos.lerp(desired, Math.min(1, dt * 20));
      this.camera.position.copy(this.camPos);
      const tgt = carPos.clone().addScaledVector(forward, 8).add(new THREE.Vector3(0, 1.0, 0));
      this.camera.lookAt(tgt);
    } else if (this.cameraMode === "orbit") {
      this.orbitAngle += dt * 0.4;
      const desired = carPos.clone().add(new THREE.Vector3(
        Math.cos(this.orbitAngle) * this.orbitDist,
        this.orbitHeight,
        Math.sin(this.orbitAngle) * this.orbitDist
      ));
      this.camPos.lerp(desired, Math.min(1, dt * 3));
      this.camera.position.copy(this.camPos);
      this.camera.lookAt(carPos);
    } else {
      // cinematic — slow pan around, sometimes tracking
      this.cineTime += dt;
      const ang = this.cineTime * 0.25;
      const r = 11 + Math.sin(this.cineTime * 0.2) * 3;
      const desired = carPos.clone().add(new THREE.Vector3(
        Math.cos(ang) * r,
        4 + Math.sin(this.cineTime * 0.3) * 2,
        Math.sin(ang) * r
      ));
      this.camPos.lerp(desired, Math.min(1, dt * 2));
      this.camera.position.copy(this.camPos);
      this.camera.lookAt(carPos);
    }
  }

  private updateSkids(dt: number) {
    const forward = new THREE.Vector3(Math.sin(this.heading), 0, Math.cos(this.heading));
    const right = new THREE.Vector3(Math.cos(this.heading), 0, -Math.sin(this.heading));
    const vForward = this.vel.dot(forward);
    const vRight = this.vel.dot(right);
    const slip = Math.abs(vRight);
    const speed = this.vel.length();
    // skid when handbraking with speed, or high slip
    const isSkidding = (this.input.handbrake || slip > 5) && speed > 4 && !this.airborne;
    // rear wheel world positions
    const rwL = this.pos.clone().addScaledVector(right, 1.05).addScaledVector(forward, -1.45);
    const rwR = this.pos.clone().addScaledVector(right, -1.05).addScaledVector(forward, -1.45);

    if (isSkidding) {
      // movement since last frame
      if (this.lastSkidPosL && this.lastSkidPosR) {
        const dL = rwL.clone().sub(this.lastSkidPosL);
        const dR = rwR.clone().sub(this.lastSkidPosR);
        if (dL.length() > 0.05) this.addSkidSegment(this.lastSkidPosL, dL, 0.28);
        if (dR.length() > 0.05) this.addSkidSegment(this.lastSkidPosR, dR, 0.28);
      }
      this.lastSkidPosL = rwL.clone();
      this.lastSkidPosR = rwR.clone();
      // tire smoke
      if (Math.random() < 0.7) {
        this.spawnTireSmoke(rwL.x, rwL.z, slip * 0.4 + (this.input.handbrake ? 2 : 0));
        this.spawnTireSmoke(rwR.x, rwR.z, slip * 0.4 + (this.input.handbrake ? 2 : 0));
      }
    } else {
      this.lastSkidPosL = undefined;
      this.lastSkidPosR = undefined;
    }

    // dust when accelerating hard on ground
    if (this.input.throttle > 0.6 && speed > 2 && !this.airborne && Math.random() < 0.5) {
      this.spawnDust(rwL.x, 0.05, rwL.z, 1);
      this.spawnDust(rwR.x, 0.05, rwR.z, 1);
    }
    void dt;
  }

  private updateLights() {
    // keep sun shadow centered on car for crisp shadows
    this.sun.position.set(this.pos.x + 60, 90, this.pos.z + 30);
    this.sun.target.position.set(this.pos.x, 0, this.pos.z);
    this.sun.target.updateMatrixWorld();
  }

  private onResize = () => {
    if (this.disposed) return;
    this.camera.aspect = window.innerWidth / window.innerHeight;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(window.innerWidth, window.innerHeight);
  };

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    window.removeEventListener("resize", this.onResize);
    this.renderer.dispose();
    this.scene.traverse((obj) => {
      const m = obj as THREE.Mesh;
      if (m.geometry) m.geometry.dispose();
      const mat = (m as any).material;
      if (Array.isArray(mat)) mat.forEach((x) => x.dispose());
      else if (mat) mat.dispose();
    });
  }
}
