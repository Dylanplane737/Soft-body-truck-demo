'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import { CarSim, type CameraMode, type HUDState } from '@/lib/car-sim'

const CAMERAS: { id: CameraMode; label: string }[] = [
  { id: 'chase', label: 'Chase' },
  { id: 'hood', label: 'Hood' },
  { id: 'orbit', label: 'Orbit' },
  { id: 'cinematic', label: 'Cinematic' },
]

export default function Home() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const simRef = useRef<CarSim | null>(null)
  const keys = useRef<Record<string, boolean>>({})
  const [hud, setHud] = useState<HUDState>({ speed: 0, gear: 'N', rpm: 0, drift: 0, damage: 0, airborne: false })
  const [started, setStarted] = useState(false)
  const [colors, setColors] = useState<{ idx: number; name: string; hex: number }[]>([])
  const [colorIdx, setColorIdx] = useState(0)
  const [cameraMode, setCameraMode] = useState<CameraMode>('chase')
  const [night, setNight] = useState(false)
  const [driftFlash, setDriftFlash] = useState(false)
  const [crashFlash, setCrashFlash] = useState(0)

  // ---- boot the sim ----
  useEffect(() => {
    if (!canvasRef.current) return
    const sim = new CarSim(canvasRef.current)
    simRef.current = sim
    setColors(sim.getCarColors())
    return () => {
      sim.dispose()
      simRef.current = null
    }
  }, [])

  // ---- keyboard input ----
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', ' '].includes(e.key)) e.preventDefault()
      keys.current[e.key.toLowerCase()] = true
      if (e.key.toLowerCase() === 'r' && simRef.current) simRef.current.input.reset = true
      if (e.key.toLowerCase() === 'h') setNight((n) => !n)
      if (!started) setStarted(true)
    }
    const up = (e: KeyboardEvent) => { keys.current[e.key.toLowerCase()] = false }
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    return () => {
      window.removeEventListener('keydown', down)
      window.removeEventListener('keyup', up)
    }
  }, [started])

  // ---- sync input + read HUD every frame ----
  useEffect(() => {
    let raf = 0
    let prevDamage = 0
    let driftTimer = 0
    const loop = () => {
      raf = requestAnimationFrame(loop)
      const sim = simRef.current
      if (!sim) return
      const k = keys.current
      sim.input.throttle = k['arrowup'] || k['w'] ? 1 : 0
      sim.input.brake = k['arrowdown'] || k['s'] ? 1 : 0
      sim.input.steer = (k['arrowleft'] || k['a'] ? -1 : 0) + (k['arrowright'] || k['d'] ? 1 : 0)
      sim.input.handbrake = !!k[' '] || !!k['shift']
      const h = sim.getHUD()
      setHud(h)
      // drift flash
      if (h.drift > 6) {
        driftTimer = 0.15
        setDriftFlash(true)
      } else {
        driftTimer -= 0.016
        if (driftTimer <= 0) setDriftFlash(false)
      }
      // crash flash when damage jumps
      if (h.damage - prevDamage > 0.01) {
        setCrashFlash(1)
        setTimeout(() => setCrashFlash(0), 220)
      }
      prevDamage = h.damage
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [])

  // ---- control helpers ----
  const press = useCallback((key: string, on: boolean) => {
    keys.current[key] = on
    if (!started) setStarted(true)
  }, [started])

  const setColor = (i: number) => {
    setColorIdx(i)
    simRef.current?.setColor(i)
  }
  const setCam = (m: CameraMode) => {
    setCameraMode(m)
    simRef.current?.setCameraMode(m)
  }
  const toggleNight = () => {
    const n = !night
    setNight(n)
    simRef.current?.setNight(n)
  }
  const reset = () => {
    if (simRef.current) simRef.current.input.reset = true
  }

  const speed = Math.round(hud.speed)
  const kmh = hud.speed
  // gauge needle: 0..220 km/h mapped to -120deg..+120deg
  const needleDeg = -120 + Math.min(kmh, 220) / 220 * 240

  return (
    <div className="relative w-full h-screen overflow-hidden bg-black text-white select-none">
      {/* 3D canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full block" />

      {/* crash flash overlay */}
      <div
        className="pointer-events-none absolute inset-0 transition-opacity duration-200"
        style={{ background: 'radial-gradient(circle, rgba(255,80,40,0.45), transparent 70%)', opacity: crashFlash }}
      />

      {/* vignette */}
      <div className="pointer-events-none absolute inset-0" style={{ boxShadow: 'inset 0 0 220px rgba(0,0,0,0.55)' }} />

      {/* ---- Top bar: title + toggles ---- */}
      <header className="absolute top-0 left-0 right-0 flex items-start justify-between p-3 sm:p-4 pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-2 rounded-xl bg-black/45 backdrop-blur-md px-3 py-2 border border-white/10">
          <div className="h-7 w-7 rounded-md grid place-items-center" style={{ background: 'linear-gradient(135deg,#ff5a4d,#ffb02e)' }}>
            <span className="text-black font-black text-sm">3D</span>
          </div>
          <div className="leading-tight">
            <div className="font-semibold text-sm tracking-tight">Softbody Car Sim</div>
            <div className="text-[10px] text-white/60 -mt-0.5">Three.js · arcade physics · crumple on impact</div>
          </div>
        </div>

        <div className="pointer-events-auto flex items-center gap-2">
          <button
            onClick={toggleNight}
            className="rounded-lg bg-black/45 backdrop-blur-md border border-white/10 px-3 py-2 text-xs font-medium hover:bg-white/10 transition-colors"
          >
            {night ? '☀ Day' : '☾ Night'}
          </button>
          <button
            onClick={reset}
            className="rounded-lg bg-black/45 backdrop-blur-md border border-white/10 px-3 py-2 text-xs font-medium hover:bg-white/10 transition-colors"
          >
            ↻ Reset
          </button>
        </div>
      </header>

      {/* ---- Left panel: speedometer + status ---- */}
      <section className="absolute left-3 sm:left-4 top-20 sm:top-24 pointer-events-none">
        <div className="pointer-events-auto rounded-2xl bg-black/45 backdrop-blur-md border border-white/10 p-3 sm:p-4 w-[200px] sm:w-[230px]">
          {/* gauge */}
          <div className="relative mx-auto" style={{ width: 170, height: 170 }}>
            <svg viewBox="0 0 200 200" className="w-full h-full">
              <defs>
                <linearGradient id="gaugeArc" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#3ddc84" />
                  <stop offset="55%" stopColor="#ffb02e" />
                  <stop offset="100%" stopColor="#ff5a4d" />
                </linearGradient>
              </defs>
              {/* arc track */}
              <path d="M 30 160 A 80 80 0 1 1 170 160" fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="10" strokeLinecap="round" />
              {/* arc fill */}
              <path
                d="M 30 160 A 80 80 0 1 1 170 160"
                fill="none"
                stroke="url(#gaugeArc)"
                strokeWidth="10"
                strokeLinecap="round"
                strokeDasharray={`${Math.min(kmh, 220) / 220 * 377} 400`}
              />
              {/* ticks */}
              {Array.from({ length: 9 }).map((_, i) => {
                const a = (-120 + (i / 8) * 240) * Math.PI / 180
                const x1 = 100 + Math.cos(a) * 70, y1 = 100 + Math.sin(a) * 70
                const x2 = 100 + Math.cos(a) * 80, y2 = 100 + Math.sin(a) * 80
                return <line key={i} x1={x1} y1={y1} x2={x2} y2={y2} stroke="rgba(255,255,255,0.4)" strokeWidth="2" />
              })}
              {/* needle */}
              <g style={{ transform: `rotate(${needleDeg}deg)`, transformOrigin: '100px 100px', transition: 'transform 80ms linear' }}>
                <line x1="100" y1="100" x2="100" y2="35" stroke="#ff5a4d" strokeWidth="3" strokeLinecap="round" />
                <circle cx="100" cy="100" r="6" fill="#ff5a4d" />
              </g>
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <div className="text-3xl font-black tabular-nums leading-none">{speed}</div>
              <div className="text-[10px] text-white/60 mt-0.5">km/h</div>
            </div>
          </div>

          {/* gear + rpm bar */}
          <div className="mt-2 flex items-center gap-3">
            <div className="flex flex-col items-center justify-center w-9 h-9 rounded-lg bg-white/10 border border-white/10">
              <span className="text-[8px] text-white/50 leading-none">GEAR</span>
              <span className="text-base font-black leading-none">{hud.gear}</span>
            </div>
            <div className="flex-1">
              <div className="text-[9px] text-white/50 mb-1">RPM</div>
              <div className="h-2 rounded-full bg-white/10 overflow-hidden">
                <div className="h-full rounded-full transition-[width] duration-100"
                  style={{ width: `${hud.rpm * 100}%`, background: 'linear-gradient(90deg,#3ddc84,#ffb02e,#ff5a4d)' }} />
              </div>
            </div>
          </div>

          {/* damage bar */}
          <div className="mt-3">
            <div className="flex justify-between text-[9px] text-white/50 mb-1">
              <span>DAMAGE</span><span>{Math.round(hud.damage * 100)}%</span>
            </div>
            <div className="h-2 rounded-full bg-white/10 overflow-hidden">
              <div className="h-full rounded-full transition-[width] duration-200"
                style={{ width: `${hud.damage * 100}%`, background: hud.damage > 0.66 ? '#ff5a4d' : hud.damage > 0.33 ? '#ffb02e' : '#3ddc84' }} />
            </div>
          </div>

          {/* status chips */}
          <div className="mt-3 flex flex-wrap gap-1.5">
            {hud.airborne && <span className="text-[10px] px-2 py-0.5 rounded-full bg-sky-400/20 text-sky-300 border border-sky-400/30">AIRBORNE</span>}
            <span className={`text-[10px] px-2 py-0.5 rounded-full border transition-colors ${driftFlash ? 'bg-amber-400/25 text-amber-200 border-amber-400/40' : 'bg-white/5 text-white/40 border-white/10'}`}>
              DRIFT
            </span>
          </div>
        </div>
      </section>

      {/* ---- Right panel: car color + camera ---- */}
      <section className="absolute right-3 sm:right-4 top-20 sm:top-24 pointer-events-none">
        <div className="pointer-events-auto rounded-2xl bg-black/45 backdrop-blur-md border border-white/10 p-3 sm:p-4 w-[180px] sm:w-[200px]">
          <div className="text-[10px] text-white/50 font-medium mb-2 tracking-wider">PAINT</div>
          <div className="grid grid-cols-3 gap-2">
            {colors.map((c, i) => (
              <button
                key={c.idx}
                onClick={() => setColor(c.idx)}
                aria-label={c.name}
                title={c.name}
                className={`aspect-square rounded-lg border-2 transition-all ${colorIdx === i ? 'border-white scale-105' : 'border-white/10 hover:border-white/40'}`}
                style={{ background: `#${c.hex.toString(16).padStart(6, '0')}` }}
              />
            ))}
          </div>

          <div className="text-[10px] text-white/50 font-medium mt-4 mb-2 tracking-wider">CAMERA</div>
          <div className="grid grid-cols-2 gap-1.5">
            {CAMERAS.map((c) => (
              <button
                key={c.id}
                onClick={() => setCam(c.id)}
                className={`text-[11px] py-1.5 rounded-md border transition-all ${cameraMode === c.id ? 'bg-white text-black border-white font-semibold' : 'bg-white/5 text-white/70 border-white/10 hover:bg-white/10'}`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ---- Mobile touch controls (bottom area, above footer) ---- */}
      <section className="absolute bottom-16 left-0 right-0 px-3 sm:hidden pointer-events-none select-none">
        <div className="flex items-end justify-between gap-2">
          {/* steering */}
          <div className="pointer-events-auto flex gap-2">
            <TouchBtn label="◀" onDown={() => press('a', true)} onUp={() => press('a', false)} />
            <TouchBtn label="▶" onDown={() => press('d', true)} onUp={() => press('d', false)} />
          </div>
          {/* pedals */}
          <div className="pointer-events-auto flex gap-2">
            <TouchBtn label="B" sub="brake" wide onDown={() => press('s', true)} onUp={() => press('s', false)} color="rose" />
            <TouchBtn label="A" sub="gas" wide onDown={() => press('w', true)} onUp={() => press('w', false)} color="emerald" />
          </div>
        </div>
        <div className="mt-2 flex justify-center">
          <button
            onPointerDown={() => press(' ', true)} onPointerUp={() => press(' ', false)} onPointerLeave={() => press(' ', false)}
            className="pointer-events-auto text-xs px-4 py-2 rounded-lg bg-amber-400/20 text-amber-200 border border-amber-400/40 font-semibold active:scale-95 transition"
          >
            HANDBRAKE / DRIFT
          </button>
        </div>
      </section>

      {/* ---- Start hint ---- */}
      {!started && (
        <div className="absolute inset-0 grid place-items-center pointer-events-none">
          <div className="pointer-events-auto text-center rounded-2xl bg-black/55 backdrop-blur-md border border-white/10 px-6 py-5 max-w-sm">
            <div className="text-lg font-bold mb-1">Ready to drive?</div>
            <div className="text-sm text-white/70 leading-relaxed">
              Use <Key>W</Key>/<Key>↑</Key> to accelerate, <Key>S</Key>/<Key>↓</Key> to brake/reverse,<br />
              <Key>A</Key><Key>D</Key> or <Key>←</Key><Key>→</Key> to steer, <Key>Space</Key> to drift.<br />
              <span className="text-amber-300">Crash into the crates & walls to crumple the body.</span>
            </div>
          </div>
        </div>
      )}

      {/* ---- Sticky footer ---- */}
      <footer className="absolute bottom-0 left-0 right-0 px-3 pb-3 pt-2 bg-gradient-to-t from-black/70 to-transparent">
        <div className="hidden sm:flex items-center justify-between gap-3 rounded-xl bg-black/45 backdrop-blur-md border border-white/10 px-3 py-2 text-xs">
          <div className="flex items-center gap-1.5 text-white/70">
            <Kbd>W</Kbd><Kbd>A</Kbd><Kbd>S</Kbd><Kbd>D</Kbd>
            <span className="mx-1 text-white/40">drive</span>
            <Kbd>Space</Kbd><span className="mx-1 text-white/40">drift</span>
            <Kbd>R</Kbd><span className="text-white/40">reset</span>
            <Kbd>H</Kbd><span className="text-white/40">night</span>
          </div>
          <div className="text-white/40 hidden md:block">Built with Three.js · softbody-style vertex crumpling on impact</div>
        </div>
        <div className="sm:hidden text-center text-[10px] text-white/50 pt-1">
          Tap gas/brake/steer buttons · long-press handbrake to drift
        </div>
      </footer>
    </div>
  )
}

function Key({ children }: { children: React.ReactNode }) {
  return <kbd className="inline-block px-1.5 py-0.5 rounded bg-white/15 border border-white/20 text-[11px] font-mono mx-0.5">{children}</kbd>
}
function Kbd({ children }: { children: React.ReactNode }) {
  return <kbd className="inline-block min-w-6 text-center px-1.5 py-0.5 rounded bg-white/10 border border-white/15 text-[11px] font-mono">{children}</kbd>
}

function TouchBtn({
  label, sub, onDown, onUp, wide, color = 'slate',
}: {
  label: string; sub?: string; onDown: () => void; onUp: () => void; wide?: boolean
  color?: 'slate' | 'emerald' | 'rose'
}) {
  const colorMap = {
    slate: 'bg-white/15 border-white/20 text-white',
    emerald: 'bg-emerald-500/30 border-emerald-400/50 text-emerald-100',
    rose: 'bg-rose-500/30 border-rose-400/50 text-rose-100',
  } as const
  return (
    <button
      onPointerDown={(e) => { e.preventDefault(); onDown() }}
      onPointerUp={(e) => { e.preventDefault(); onUp() }}
      onPointerLeave={() => onUp()}
      onPointerCancel={() => onUp()}
      className={`${colorMap[color]} ${wide ? 'w-20 h-20' : 'w-14 h-14'} rounded-2xl border backdrop-blur-md grid place-items-center font-bold active:scale-90 transition-transform touch-none select-none`}
    >
      <span className="text-xl leading-none">{label}</span>
      {sub && <span className="text-[9px] opacity-70 mt-0.5 uppercase tracking-wide">{sub}</span>}
    </button>
  )
}
